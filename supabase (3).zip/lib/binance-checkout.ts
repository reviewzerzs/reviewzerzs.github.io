// Binance Pay integration removed. LTC payments use a static wallet address.
export {};
