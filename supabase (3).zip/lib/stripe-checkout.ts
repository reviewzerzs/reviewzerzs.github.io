import { supabase } from './supabase';

async function getAccessToken(): Promise<string> {
  const { data: { session } } = await supabase.auth.getSession();
  if (!session?.access_token) throw new Error('User not authenticated');
  return session.access_token;
}

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;

/* ── Hosted checkout session (used by dashboard) ── */

interface CheckoutByAmount {
  amount: number;
  product_name: string;
  success_url: string;
  cancel_url: string;
  mode?: 'payment';
  order_id?: string;
}

export async function createCheckoutSession(
  request: CheckoutByAmount
): Promise<{ sessionId: string; url: string }> {
  const token = await getAccessToken();

  const response = await fetch(`${supabaseUrl}/functions/v1/stripe-checkout`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify(request),
  });

  if (!response.ok) {
    const err = await response.json();
    throw new Error(err.error || 'Failed to create checkout session');
  }

  return response.json();
}

export interface PaymentIntentRequest {
  amount: number;
  order_id: string;
  product_name: string;
}

export interface PaymentIntentResponse {
  clientSecret: string;
  paymentIntentId: string;
}

export async function createPaymentIntent(
  request: PaymentIntentRequest
): Promise<PaymentIntentResponse> {
  const token = await getAccessToken();

  const response = await fetch(`${supabaseUrl}/functions/v1/create-payment-intent`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify(request),
  });

  if (!response.ok) {
    const err = await response.json();
    throw new Error(err.error || 'Failed to create payment intent');
  }

  return response.json();
}
